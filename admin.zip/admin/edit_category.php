<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/layout.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$category = ['name' => ''];
$error = '';
$success = '';

// Load existing category
if ($id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $fetched = $stmt->fetch();
    if ($fetched) {
        $category = $fetched;
    } else {
        $error = "Category not found.";
        $id = 0;
    }
}

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        http_response_code(403);
        die('Invalid CSRF token.');
    }
    $name = trim($_POST['name'] ?? '');
    $slug = trim($_POST['slug'] ?? '');
    $imagePath = $category['image_path'] ?? null;

    if (empty($slug) && !empty($name)) {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name), '-'));
    }

    // Handle Image Upload
    if (!empty($_FILES['category_image']['name'])) {
        $file = $_FILES['category_image'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($ext, $allowed)) {
            $destDir = __DIR__ . '/../uploads/categories/';
            if (!is_dir($destDir)) mkdir($destDir, 0755, true);

            $newName = 'cat_' . uniqid() . '.' . $ext;
            if (move_uploaded_file($file['tmp_name'], $destDir . $newName)) {
                // Delete old image if exists
                if ($imagePath && file_exists($destDir . $imagePath)) {
                    unlink($destDir . $imagePath);
                }
                $imagePath = $newName;
            }
        }
    }

    if (empty($name)) {
        $error = "Category name is required.";
    } else {
        try {
            if ($id > 0) {
                // UPDATE
                $stmt = $pdo->prepare("UPDATE categories SET name = :name, slug = :slug, image_path = :image WHERE id = :id");
                $stmt->execute([':name' => $name, ':slug' => $slug, ':image' => $imagePath, ':id' => $id]);
                $success = "Category updated successfully.";
            } else {
                // INSERT
                $stmt = $pdo->prepare("INSERT INTO categories (name, slug, image_path) VALUES (:name, :slug, :image)");
                $stmt->execute([':name' => $name, ':slug' => $slug, ':image' => $imagePath]);
            $id = $pdo->lastInsertId();
            $success = "Category created successfully.";
        }
        if (class_exists('HookRegistry')) {
            HookRegistry::doAction('category_saved', $id);
        }
        $category['name'] = $name;
        $category['slug'] = $slug;
        $category['image_path'] = $imagePath;
        } catch (\PDOException $e) {
            if ($e->getCode() == 23000) {
                // Unique constraint violation
                $error = "A category with that name already exists.";
            } else {
                error_log('Category save failed: ' . $e->getMessage());
                $error = "Unable to save category right now.";
            }
        }
    }
}

echo renderAdminHeader($id > 0 ? "Edit Category - " . htmlspecialchars($category['name']) : "Create New Category");
?>

<div class="mb-6 flex justify-between items-center">
    <div>
        <h1 class="text-2xl font-bold text-gray-900 leading-tight"><?= $id > 0 ? 'Edit Category' : 'New Category' ?></h1>
    </div>
    <a href="categories.php" class="text-gray-600 hover:text-gray-900 text-sm font-medium">&larr; Back to Categories</a>
</div>

<?php if ($error): ?>
    <div class="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative">
        <?= htmlspecialchars($error) ?>
    </div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded relative flex justify-between items-center">
        <span><?= htmlspecialchars($success) ?></span>
        <?php if (!isset($_GET['id'])): ?>
            <a href="edit_category.php" class="ml-4 text-xs font-bold uppercase tracking-wider bg-green-100 px-3 py-1.5 rounded hover:bg-green-200 transition">Add Another</a>
        <?php endif; ?>
    </div>
<?php endif; ?>

<div class="max-w-2xl">
    <form method="POST" action="" enctype="multipart/form-data" class="bg-white rounded-lg border border-gray-200 shadow-sm">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(ensureCsrfToken()) ?>">
        <div class="p-6">
            <div class="mb-4">
                <label for="name" class="block text-sm font-medium text-gray-700 mb-1">Category Name *</label>
                <input type="text" id="name" name="name" value="<?= htmlspecialchars($category['name'] ?? '') ?>" required
                       class="w-full border border-gray-300 rounded-md px-3 py-2 outline-none focus:border-gray-900 focus:ring-1 focus:ring-gray-900 shadow-sm sm:text-sm">
            </div>

            <div class="mb-6">
                <label for="slug" class="block text-sm font-medium text-gray-700 mb-1">URL Slug</label>
                <input type="text" id="slug" name="slug" value="<?= htmlspecialchars($category['slug'] ?? '') ?>"
                       placeholder="e.g. stamps-and-coins (auto-generated if empty)"
                       class="w-full border border-gray-300 rounded-md px-3 py-2 outline-none focus:border-gray-900 focus:ring-1 focus:ring-gray-900 shadow-sm sm:text-sm">
                <p class="text-[10px] text-gray-400 mt-1 italic">Used for clean URLs like /category/stamps-and-coins</p>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Category Thumbnail</label>
                <?php if (!empty($category['image_path'])): ?>
                    <div class="mb-4">
                        <img src="<?= SITE_URL ?>/uploads/categories/<?= htmlspecialchars($category['image_path']) ?>" 
                             class="h-32 w-32 object-cover rounded-lg border border-gray-200 shadow-sm" alt="Current thumb">
                        <p class="text-xs text-gray-400 mt-2 italic">Uploading a new image will replace the current one.</p>
                    </div>
                <?php endif; ?>
                <div class="flex items-center gap-3">
                    <input type="file" name="category_image" accept="image/*"
                           class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200">
                </div>
                <p class="text-xs text-gray-400 mt-2">Recommended: 400x400px (WebP, JPG, or PNG).</p>
            </div>
            
            <!-- SEO and Additional Stats -->
            <?php if (class_exists('HookRegistry')) {
                HookRegistry::doAction('admin_category_edit_after_fields', $id, $category);
            } ?>
        </div>

        <div class="p-6 border-t border-gray-200 rounded-b-lg flex justify-end gap-3 bg-gray-50">
            <a href="categories.php" class="px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">Cancel</a>
            <button type="submit" class="px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-gray-900 hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">
                <?= $id > 0 ? 'Update Category' : 'Save Category' ?>
            </button>
        </div>
    </form>
</div>

<?= renderAdminFooter(); ?>
